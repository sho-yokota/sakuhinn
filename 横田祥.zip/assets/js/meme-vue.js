(function(){

	if ( !'Vue' in window ) {
		console.error('Vueが読み込まれてません');
	}

	var _extend = function(target, object1, object2){
		var i;
		for ( i in object1 ) {
			target[i] = object1[i];
		}
		if ( object2 ) {
			for ( i in object2 ) {
				target[i] = object2[i];
			}
		}
		return target;
	};

	var _urlParse = function(url){
		var path = url.split('?')[0];
		var paramsStr = url.split('?')[1] || '';
		var params = {};
		if ( paramsStr ) {
			paramsStr.split('&').forEach(function(keyval){
				var key = keyval.split('=')[0];
				var val = keyval.split('=')[1] || '';
				params[key] = val;
			});
		}
		return {
			all: url,
			path: path,
			params: params
		};
	};

	var _urlStringify = function(parsedUrl){
		var params = [], key;
		for (key in parsedUrl.params) {
			if ( parsedUrl.params[key] ) {
				params.push(key + '=' + parsedUrl.params[key]);
			}
		}
		return parsedUrl.path + (params.length ? '?' + params.join('&') : '');
	};

	var _overrideUrlParams = function(url, params){
		var parsedUrl = _urlParse(url);
		_extend(parsedUrl.params, params);
		return _urlStringify(parsedUrl);
	};

	// 日時
	var _dateformat = (function(){
		var REPLACES = [
			{reg: /YYYY(?!Y)/g, replace: function(d){ return d.getFullYear(); }},
			{reg: /YY(?!Y)/g, replace: function(d){ return (d.getFullYear() + '').slice(-2); }},
			{reg: /MM(?!M)/g, replace: function(d){ return ('0' + (d.getMonth() + 1)).slice(-2); }},
			{reg: /M(?!M)/g, replace: function(d){ return d.getMonth() + 1; }},
			{reg: /DD(?!D)/g, replace: function(d){ return ('0' + d.getDate()).slice(-2); }},
			{reg: /D(?!D)/g, replace: function(d){ return d.getDate(); }},
			{reg: /HH(?!H)/g, replace: function(d){ return ('0' + d.getHours()).slice(-2); }},
			{reg: /H(?!H)/g, replace: function(d){ return d.getHours(); }},
			{reg: /hh(?!h)/g, replace: function(d){ return ('0' +d.getHours() % 12).slice(-2); }},
			{reg: /h(?!h)/g, replace: function(d){ return d.getHours() % 12; }},
			{reg: /mm(?!m)/g, replace: function(d){ return ('0' + d.getMinutes()).slice(-2); }},
			{reg: /m(?!m)/g, replace: function(d){ return d.getMinutes(); }},
			{reg: /ss(?!s)/g, replace: function(d){ return ('0' + d.getSeconds()).slice(-2); }},
			{reg: /s(?!s)/g, replace: function(d){ return d.getSeconds(); }},
			{reg: /W(?!W)/g, replace: function(d){ return ['日','月','火','水','木','金','土'][d.getDay()]; }},
		];
		return function(d, format){
			d = new Date(d);
			for (var i = 0; i < REPLACES.length; i++) {
				format = format.replace(REPLACES[i].reg, REPLACES[i].replace(d));
			}
			return format;
		};
	})();


	// フィルター 文字カット
	Vue.filter('cut', function(val, len, txt){
		return  val.length > len ? val.substr(0, len) + (txt || '') : val;
	});

	// フィルター 日時の文字列を返す
	Vue.filter('dateformat', function(val, format){
		console.log(val);
		return _dateformat(val, format);
	});

	// メイン
	window.memeVue = {

		// デフォルトのコンポーネント
		defaultType: 'base',

		// 登録されたVueコンストラクタ
		Vues: {
			// ベースとなる Vueコンストラクタ
			base: Vue.extend({
				delimiters: ['<@', '@>'],
				data: function () {
					return {
						isFetching: false,
						fetchedUrl: '',
						json: null,
					};
				},
				computed: {
					isSuccess: function(){
						return json && json.status === 'success';
					},
					fetchedPath: function(){
						var url = this.fetchedUrl;
						return url ? url.split('?')[0] : null;
					},
					fetchedParams: function(){
						var paramsStr = this.fetchedUrl.split('?')[1];
						var params = {};
						if ( !paramsStr ) {
							return null;
						}
						paramsStr.split('&').forEach(function(keyval){
							var key = keyval.split('=')[0];
							var val = keyval.split('=')[1] || '';
							params[key] = val;
						});
						return params;
					},
				},
				watch: {
				},
				methods: {
					getFetchedUrlParams: function(key){
						var params = _urlParse(this.fetchedUrl).params;
						return key ? params[key] : params;
					},
					getOverrideFetchedUrl: function(params){
						return _overrideUrlParams(this.fetchedUrl, params);
					},

					// 引数をオブジェクト例えば{page_no: 1}にしたら前回取得したURLのパラメーターのみ変更したURLでfetchする
					fetch: function(url){
						if ( typeof url === 'object' ) {
							url = this.getOverrideFetchedUrl(url);
						}
						this.isFetching = true;
						var success = function(json){
							this.isFetching = false;
							//// ページ描画時におけるcheckクラス付与処理
                            if (url.match(/photo/)){
                                // 写真館でのみ
                                if ($.cookie('cart') != null){
                                    // カートに1件以上入っている場合
                                    var cookie = JSON.parse($.cookie('cart'));
                                } else{
                                    // カートに1件も入っていない場合
                                    var cookie = {};
                                }
                                var check = new Array();
                                // カートに入っているのものを集めた配列
                                $.each(cookie, function(index, val){
                                    check[index] = index;
                                });
                                // checkクラス付与
                                $.each(json.data, function(i,element){
                                    // if (check.includes(element.id)){
                                    if (check.indexOf(element.id) !== -1){
                                        json.data[i]['check'] = true;
                                        json.data[i]['message'] = 'カートから外す';
                                    } else{
                                        json.data[i]['check'] = false;
                                        json.data[i]['message'] = 'カートに入れる';
                                    }
                                });
                                //// 最初の描画時におけるclass:check付与処理 ここまで
                            }
                            this.json = json;
                            this.fetchedUrl = url;
                            this.$nextTick(function(){
                                this.$emit('fetched', JSON.parse(JSON.stringify(json)));
                            });
						}.bind(this);

						var fail = function(){
							this.isFetching = false;
							this.$emit('fetchFail');
							console.error(xhr);
						}.bind(this);

						var xhr = new XMLHttpRequest();
						xhr.open('GET', url, true);
						xhr.onload = function(){
							if ( xhr.status !== 200 ) {
								return fail();
							}
							var json = JSON.parse(xhr.responseText);
							if ( json.status !== 'success' ) {
								return fail();
							}
							success(json);
						};
						xhr.onerror = function(){
							fail();
						};
						xhr.send();
					},
				},
			})
		},

		// memeVueのコンストラクタを登録
		// 一応直にVueのコンストラクタを引数にすることもできる
		register: function(name, vueSetting){
			this.Vues[name] = typeof vueSetting === 'object' ? this.Vues.base.extend(vueSetting) : vueSetting;
		},

		// 初期化で作られたインスタンス
		vueInstances: [],

		// 要素（または要素のセレクター）を引数にインスタンスを取得
		getVueInstance: function(el){
			if ( typeof el === 'string' ) {
				el = document.querySelector(el);
			}
			var i = 0, ii = this.vueInstances.length;
			for (; i < ii; i++) {
				if ( el === this.vueInstances[i].$el ) {
					return this.vueInstances[i];
				}
			}
			return null;
		},

		// 初期化
		init: function(){
			var self = this;
			document.addEventListener('DOMContentLoaded', function(){
				Array.prototype.forEach.call(document.querySelectorAll('[meme-vue], [meme-vue-url], [meme-vue-data]'), function(el){
					var MyVue = self.Vues[el.getAttribute('meme-vue') || self.defaultType];
					var data = JSON.parse(el.getAttribute('meme-vue-data'));
					var url = el.getAttribute('meme-vue-url') || '';
					var onReady = el.getAttribute('meme-vue-ready') ? window[el.getAttribute('meme-vue-ready')] : null;
					// 開発時のみコメントアウトを外す
                    // Vue.config.devtools = true;
                    // Vue.config.debug = true;
					var vue = new MyVue({
						el: el,
						data: {
							'checkFlg': false,
                        },
					});

					self.vueInstances.push(vue);

					if ( url ) {
						vue.fetch(url);
					}
					if ( onReady ) {
						if ( url ) {
							vue.$once('fetched', function(){
								onReady(el, vue);
							});
						}
						else {
							onReady(el, vue);
						}
					}
				});

			});
		}
	};
})();
// Vueの設定を登録
memeVue.register('page', {
	computed: {
		data: function(){
			return this.json && this.json.data ? this.json.data : [];
		},
		hasData: function(){
			return this.json && this.json.data && this.json.data.length;
		},
		noData: function(){
			if ( !this.json ) {
				return false;
			}
			return this.json.data && this.json.data.length === 0;
		},
		pager: function(){
			return this.json && this.json.pager ? this.json.pager : null;
		},
		hasPager: function(){
			return this.json && this.json.pager && this.json.pager.max >= 2;
		},
	},
	methods: {
		showPage: function(page_no, noScroll){
			if ( page_no >= 1 && page_no <= this.pager.max ) {
				this.fetch({page_no: page_no});
				if ( noScroll ) {
					return;
				}
				var elTop = this.$el.getBoundingClientRect().top;
				if ( elTop < 0 ) {
					window.scrollBy(0, elTop - 30);
				}
			}
		},
		prevPage: function(noScroll){
			if ( typeof noScroll !== 'boolean' ) {
				noScroll = false;
			}
			if ( this.pager.prev_no ) {
				this.showPage(this.pager.prev_no, noScroll);
			}
		},
		nextPage: function(noScroll){
			if ( typeof noScroll !== 'boolean' ) {
				noScroll = false;
			}
			if ( this.pager.next_no ) {
				this.showPage(this.pager.next_no, noScroll);
			}
		},
		// カート追加、削除
		write: function(id){
        	var cookie = $.cookie('cart');
            if (cookie == null){
                // カートに1件もない場合
                var cartData = {};
            } else {
                // カートに1件以上登録されている場合
                var cartData = JSON.parse(cookie);
            }
            if (cartData[id] == null){
            	// 保存
                cartData[id] = 1;
			} else{
            	// 削除
                var cartData = JSON.parse($.cookie('cart'), function (key, value) {
                    if ( key != id ) {
                        // 当該idをcookieから削除
                        return value ;
                    }
                });
			}
            var json =  JSON.stringify(cartData);
            this.writeCookie('cart', json);
            // classとテキストを変更
			var filterData = this.json.data.filter(function (key,value) {
                if (key.id == id) return true;
            });
            var value = filterData[0];
            // checkクラスを反転させて、bindさせる
            value['check'] = !value['check'];
            // テキスト変更
            if (value['message'] == 'カートから外す'){
                value['message'] = 'カートに入れる';
			} else if (value['message'] == 'カートに入れる'){
                value['message'] = 'カートから外す';
			}
		},
		// cookie書き込み
        writeCookie: function(key, json){
			if (json == "{}"){
                $.cookie("cart", json, {'expires': -1, 'path':"/"});
			} else{
                $.cookie("cart", json, {'expires': 7, 'path':"/"});
			}
		},
	},
    updated: function () {
        $('.open-popup-link').magnificPopup({
            type:'image',
            disableOn: 200,
            removalDelay: 200,
            preloader: false,
            fixedContentPos: false,
            callbacks: {
                open: function(){
                },
                close: function(){
                }
            }
        });
    }
});

// デフォルトタイプを page に
memeVue.defaultType = 'page';

// 初期化
memeVue.init();