/**
 * Created by aoyagiyumi on 2017/10/03.
 */
/* メニュー
 ====================================== */
 $(function($) {
  $(document).ready(function() {
      $('.navBtn').click(function(){ //クリックしたら
          if($(this).hasClass('peke')){
              $(".nav_smp").slideUp();
              $(this).toggleClass('peke');
          }else{
              $(this).toggleClass('peke'); //toggleでクラス追加・削除
              $(".nav_smp").slideDown();}
      });
  });
});

/* リサイズしたらメニューを閉じる
====================================== */
$(function(){
  var timer = false;
  $(window).resize(function() {
      if (timer !== false) {
          clearTimeout(timer);
      }
      timer = setTimeout(function() {
              $(".navBtn").removeClass('peke'); //toggleでクラス追加・削除
              $(".nav_smp").css('display', 'none');
      });
  });
});

/* ページ内リンク
====================================== */
$(function(){
  $('a[href^="#"]').click(function() {
      var speed = 400;
      var href= $(this).attr("href");
      var target = $(href == "#" || href == "" ? 'html' : href);
      var position = target.offset().top - 120;
      $('body,html').animate({scrollTop:position}, speed, 'swing');
      return false;
  });
});

/* ナビの固定
====================================== */
$(function(){
  var nav    = $('nav.nav_pc'),
      offset = nav.offset();

  $(window).scroll(function () {

      if(window.matchMedia('(min-width:1100px)').matches){

          if($(window).scrollTop() > offset.top) {
              nav.addClass('fixed');
              $('#pageTop').addClass('topMargin--65');
          } else {
              nav.removeClass('fixed');
              $('#pageTop').removeClass('topMargin--65');
          }
      }

  });
});

/* Dropdown メニュー
====================================== */
$(function($) {
  // PC
  const dropdownTriggerPC = $('nav.nav_pc .js-dropdown > a');
  dropdownTriggerPC.on('click', function() {
      $(this).parent().toggleClass('is-open');
      $(this).parent().siblings(".js-dropdown.is-open").removeClass('is-open');
  })

  const dropdownTriggerSP = $('nav.nav_smp .js-dropdown > a');
  dropdownTriggerSP.on('click', function() {
      $(this).next().slideToggle();
      $(this).parent().toggleClass('is-open');
  });
});


/* 言語切り替え
====================================== */
$(function($) {
  var list    = $('.dropdown li.first ul');
  $(document).ready(function() {
      $('.dropdown').click(function(){ //クリックしたら
          if(list.hasClass('close')){
              list.slideUp();
              list.toggleClass('close');
          }else{
              list.toggleClass('close'); //toggleでクラス追加・削除
              list.slideDown();}
      });
  });
});


/* 画面サイズ取得
====================================== */
// $(document).ready(function () {
//     hsize = $(window).height();
//     wsize = $(window).width();
//     var area = $(".mainImgAre");
//     area.css("height", hsize + "px");
//     area.css("width", wsize + "px");
// });

$(function(){
  var timer = false;
  $(window).resize(function() {
      if (timer !== false) {
          clearTimeout(timer);
      }
      timer = setTimeout(function() {
          console.log('resized');
          hsize = $(window).height();
          wsize = $(window).width();
          var area = $(".mainImgAre");
          area.css("height", hsize + "px");
          area.css("width", wsize + "px");
      }, 200);
  });

});
// スクロールアニメーション

// ふわっと
$(function(){
  $(".effect").css("opacity","0");
  $(window).scroll(function (){
      $(".effect").each(function(){
          var imgPos = $(this).offset().top;
          var scroll = $(window).scrollTop();
          var windowHeight = $(window).height();
          if (scroll > imgPos - windowHeight + windowHeight/3){
              $(this).css("opacity","1" );
          }
      });
  });
});


// 下から
$(function(){
  $(window).scroll(function (){
      $('.fadein').each(function(){
          var elemPos = $(this).offset().top;
          var scroll = $(window).scrollTop();
          var windowHeight = $(window).height();
          if (scroll > elemPos - windowHeight + 200){
              $(this).addClass('scrollin');
          }
      });
  });
});


/* リサイズされたらリロード
====================================== */
// $(document).ready(function(){
//     if(!navigator.userAgent.match(/(iPhone|iPad|iPod|Android)/)){
//         var timer = false; //リサイズ終了フラグ
//
//         $(window).on("load resize", ReLayout); //リサイズもしくはロードされた時にReLayout呼び出し
//
//         function ReLayout() {
//             var _width = $(window).width(); //画面サイズ取得
//
//             //リサイズ終了時のみリロードする
//             if(event.type == 'resize') {
//                 if (timer !== false) {
//                     clearTimeout(timer);
//                 }
//                 timer = setTimeout(function() {
//                     location.href = location.href; //リロード12qwwes
//                 }, 200);
//
//                 hsize = $(window).height();
//                 wsize = $(window).width();
//                 area.css("height", hsize + "px");
//                 area.css("width", wsize + "px");
//             }
//
//         }
//     }
// });


/*ローディング画面を表示
＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝＝*/
$(function() {
  var h = $(window).height();
  $('#mainContents').css('display','none');
  $('#loader-bg ,#loader').height(h).css('display','block');
});

//レンタサイクル情報モーダル
$(function(){
  var $modal = $('.rentalModal');

  $('.js-rentalModal_open').on('click',function(){
      if ($modal.hasClass('is-open')) {
          $modal.removeClass('is-open');
          $('html,body').removeClass('scroll-prevent');

      } else {
          $modal.addClass('is-open');
          $('html,body').addClass('scroll-prevent');
      }
  });
  $('.js-rentalModal_close').on('click', function () {
      if ($modal.hasClass('is-open')) {
          $modal.removeClass('is-open');
          $('html,body').removeClass('scroll-prevent');

      } else {
          $modal.addClass('is-open');
          $('html,body').addClass('scroll-prevent');
      }
  });
});
